/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/JSP_Servlet/Filter.java to edit this template
 */
package filter;

import jakarta.servlet.Filter;
import jakarta.servlet.FilterChain;
import jakarta.servlet.ServletException;
import jakarta.servlet.ServletRequest;
import jakarta.servlet.ServletResponse;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;
import java.io.IOException;
import model.User;

/**
 *
 * @author vanph
 *
 */
public class AuthFilter implements Filter {

    @Override
    public void doFilter(ServletRequest request, ServletResponse response, FilterChain chain)
            throws IOException, ServletException {
        HttpServletRequest req = (HttpServletRequest) request;
        HttpServletResponse resp = (HttpServletResponse) response;

        req.setCharacterEncoding("UTF-8");   // để nhận đúng tiếng Việt từ form

        String path = req.getServletPath();      // ví dụ: /team
        String action = req.getParameter("action");
        boolean isPost = req.getMethod().equals("POST");

        // Thao tác thêm / sửa / xóa / lưu (POST) thì phải là ADMIN. Riêng /login thì cho qua.
        boolean needAdmin = ("add".equals(action) || "edit".equals(action) || "delete".equals(action) || isPost)
                && !path.equals("/login");

        if (needAdmin) {
            HttpSession session = req.getSession(false);
            User user = null;
            if (session != null) {
                user = (User) session.getAttribute("user");
            }
            if (user == null || !"ADMIN".equals(user.getRole())) {
                resp.sendRedirect(req.getContextPath() + "/login");
                return;
            }
        }
        chain.doFilter(request, response);   // cho đi tiếp vào Servlet
    }
}
