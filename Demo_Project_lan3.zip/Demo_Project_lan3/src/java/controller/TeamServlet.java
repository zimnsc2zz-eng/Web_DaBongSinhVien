/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/JSP_Servlet/Servlet.java to edit this template
 */
package controller;

import java.io.IOException;
import java.io.PrintWriter;
import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import dal.TeamDAO;
import dal.TournamentDAO;
import model.Team;

/**
 *
 * @author PRJ301
 */
public class TeamServlet extends HttpServlet {

    private TeamDAO dao = new TeamDAO();
    private TournamentDAO tournamentDAO = new TournamentDAO();

    /**
     * Processes requests for both HTTP <code>GET</code> and <code>POST</code>
     * methods.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
        try (PrintWriter out = response.getWriter()) {
            /* TODO output your page here. You may use following sample code. */
            out.println("<!DOCTYPE html>");
            out.println("<html>");
            out.println("<head>");
            out.println("<title>Servlet TeamServlet</title>");
            out.println("</head>");
            out.println("<body>");
            out.println("<h1>Servlet TeamServlet at " + request.getContextPath() + "</h1>");
            out.println("</body>");
            out.println("</html>");
        }
    }

    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        String action = request.getParameter("action");

        if ("add".equals(action)) {
            request.setAttribute("team", new Team());
            request.setAttribute("tournaments", tournamentDAO.getAll());
            request.getRequestDispatcher("/WEB-INF/views/team/form.jsp").forward(request, response);

        } else if ("edit".equals(action)) {
            int id = Integer.parseInt(request.getParameter("id"));
            Team t = dao.getById(id);
            if (t == null) {
                response.sendRedirect(request.getContextPath() + "/team");
                return;
            }
            request.setAttribute("team", t);
            request.setAttribute("tournaments", tournamentDAO.getAll());
            request.getRequestDispatcher("/WEB-INF/views/team/form.jsp").forward(request, response);

        } else {
            request.setAttribute("list", dao.getAll());
            request.getRequestDispatcher("/WEB-INF/views/team/list.jsp").forward(request, response);
        }
    }

    /**
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        String action = request.getParameter("action");

        if ("delete".equals(action)) {
            int id = Integer.parseInt(request.getParameter("id"));
            if (dao.delete(id)) {
                request.getSession().setAttribute("message", "Đã xóa đội bóng");
            } else {
                request.getSession().setAttribute("message", "Không xóa được vì đội còn cầu thủ hoặc trận đấu");
            }
            response.sendRedirect(request.getContextPath() + "/team");
            return;
        }

        Team t = new Team();
        String error = null;
        try {
            t.setId(Integer.parseInt(request.getParameter("id")));
            t.setName(request.getParameter("name").trim());
            t.setFaculty(request.getParameter("faculty").trim());
            t.setCoach(request.getParameter("coach").trim());
            t.setTournamentId(Integer.parseInt(request.getParameter("tournamentId")));

            if (t.getName().isEmpty()) {
                error = "Tên đội không được để trống";
            }
        } catch (Exception e) {
            error = "Dữ liệu không hợp lệ (hãy chọn giải đấu)";
        }

        if (error == null) {
            boolean ok;
            if (t.getId() == 0) {
                ok = dao.insert(t);
            } else {
                ok = dao.update(t);
            }
            if (ok) {
                request.getSession().setAttribute("message", "Lưu đội bóng thành công");
                response.sendRedirect(request.getContextPath() + "/team");
                return;
            }
            error = "Lưu thất bại (có thể trùng tên đội trong giải)";
        }

        request.setAttribute("error", error);
        request.setAttribute("team", t);
        request.setAttribute("tournaments", tournamentDAO.getAll());
        request.getRequestDispatcher("/WEB-INF/views/team/form.jsp").forward(request, response);
    }

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}
