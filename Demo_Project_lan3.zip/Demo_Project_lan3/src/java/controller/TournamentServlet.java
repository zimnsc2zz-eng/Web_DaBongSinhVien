/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/JSP_Servlet/Servlet.java to edit this template
 */
package controller;

import java.io.IOException;
import java.io.PrintWriter;
import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.sql.Date;
import dal.TournamentDAO;
import model.Tournament;

/**
 *
 * @author vanph
 */
public class TournamentServlet extends HttpServlet {

    private TournamentDAO dao = new TournamentDAO();

    /**
     * Processes requests for both HTTP <code>GET</code> and <code>POST</code> methods.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
        try (PrintWriter out = response.getWriter()) {
            /* TODO output your page here. You may use following sample code. */
            out.println("<!DOCTYPE html>");
            out.println("<html>");
            out.println("<head>");
            out.println("<title>Servlet TournamentServlet</title>");
            out.println("</head>");
            out.println("<body>");
            out.println("<h1>Servlet TournamentServlet at " + request.getContextPath() + "</h1>");
            out.println("</body>");
            out.println("</html>");
        }
    }

    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        //them sua  giai dau
        String action = request.getParameter("action");

        if ("add".equals(action)) {
            request.setAttribute("tournament", new Tournament());
            request.getRequestDispatcher("/WEB-INF/views/tournament/form.jsp").forward(request, response);

        } else if ("edit".equals(action)) {
            int id = Integer.parseInt(request.getParameter("id"));
            Tournament t = dao.getById(id);
            if (t == null) {
                response.sendRedirect(request.getContextPath() + "/tournament");
                return;
            }
            request.setAttribute("tournament", t);
            request.getRequestDispatcher("/WEB-INF/views/tournament/form.jsp").forward(request, response);

        } else {
            request.setAttribute("list", dao.getAll());
            request.getRequestDispatcher("/WEB-INF/views/tournament/list.jsp").forward(request, response);
        }
    }

    /**
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        //xoa luu va cap nhap giai dau
        String action = request.getParameter("action");

        if ("delete".equals(action)) {
            int id = Integer.parseInt(request.getParameter("id"));
            if (dao.delete(id)) {
                request.getSession().setAttribute("message", "Đã xóa giải đấu");
            } else {
                request.getSession().setAttribute("message", "Không xóa được vì giải đấu chưa kết thúc!");
            }
            response.sendRedirect(request.getContextPath() + "/tournament");
            return;
        }

        // add giai daui
        Tournament t = new Tournament();
        String error = null;
        try {
            t.setId(Integer.parseInt(request.getParameter("id")));
            t.setName(request.getParameter("name").trim());
            t.setLocation(request.getParameter("location").trim());
            t.setStartDate(Date.valueOf(request.getParameter("startDate")));
            t.setEndDate(Date.valueOf(request.getParameter("endDate")));

            if (t.getName().isEmpty()) {
                error = "Tên giải không được để trống";
            } else if (t.getStartDate().after(t.getEndDate())) {
                error = "Ngày bắt đầu phải trước ngày kết thúc ";
            }
        } catch (Exception e) {
            error = "Dữ liệu không hợp lệ";
        }

        // add vao db
        if (error == null) {
            boolean valid;
            if (t.getId() == 0) {
                valid = dao.insert(t);
            } else {
                valid = dao.update(t);
            }
            if (valid) {
                request.getSession().setAttribute("message", "Lưu giải đấu thành công");
                response.sendRedirect(request.getContextPath() + "/tournament");
                return;
            }
            error = "Lưu thất bại";
        }

        request.setAttribute("error", error);
        request.setAttribute("tournament", t);
        request.getRequestDispatcher("/WEB-INF/views/tournament/form.jsp").forward(request, response);
    }

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}
