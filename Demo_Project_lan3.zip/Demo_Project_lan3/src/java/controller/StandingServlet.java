/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/JSP_Servlet/Servlet.java to edit this template
 */
package controller;

import java.io.IOException;
import java.io.PrintWriter;
import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.util.List;
import dal.StandingDAO;
import dal.TournamentDAO;
import model.Tournament;

/**
 *
 * @author PRJ301
 */
public class StandingServlet extends HttpServlet {

    private StandingDAO dao = new StandingDAO();
    private TournamentDAO tournamentDAO = new TournamentDAO();

    /**
     * Processes requests for both HTTP <code>GET</code> and <code>POST</code> methods.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
        try (PrintWriter out = response.getWriter()) {
            /* TODO output your page here. You may use following sample code. */
            out.println("<!DOCTYPE html>");
            out.println("<html>");
            out.println("<head>");
            out.println("<title>Servlet StandingServlet</title>");
            out.println("</head>");
            out.println("<body>");
            out.println("<h1>Servlet StandingServlet at " + request.getContextPath() + "</h1>");
            out.println("</body>");
            out.println("</html>");
        }
    }

    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        List<Tournament> tournaments = tournamentDAO.getAll();

        // Chọn giải: lấy từ tham số tournamentId, nếu không có thì lấy giải đầu tiên
        int tournamentId = 0;
        if (request.getParameter("tournamentId") != null) {
            tournamentId = Integer.parseInt(request.getParameter("tournamentId"));
        } else if (!tournaments.isEmpty()) {
            tournamentId = tournaments.get(0).getId();
        }

        request.setAttribute("tournaments", tournaments);
        request.setAttribute("tournamentId", tournamentId);
        request.setAttribute("list", dao.getStandings(tournamentId));
        request.getRequestDispatcher("/WEB-INF/views/standing/list.jsp").forward(request, response);
    }

    /**
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        doGet(request, response);
    }

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}
