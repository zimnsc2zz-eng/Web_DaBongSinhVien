/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/JSP_Servlet/Servlet.java to edit this template
 */
package controller;

import java.io.IOException;
import java.io.PrintWriter;
import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.sql.Date;
import dal.MatchDAO;
import dal.TeamDAO;
import model.Match;
import model.Team;

/**
 *
 * @author PRJ301
 */
public class MatchServlet extends HttpServlet {

    private MatchDAO dao = new MatchDAO();
    private TeamDAO teamDAO = new TeamDAO();

    /**
     * Processes requests for both HTTP <code>GET</code> and <code>POST</code>
     * methods.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
        try (PrintWriter out = response.getWriter()) {
            /* TODO output your page here. You may use following sample code. */
            out.println("<!DOCTYPE html>");
            out.println("<html>");
            out.println("<head>");
            out.println("<title>Servlet MatchServlet</title>");
            out.println("</head>");
            out.println("<body>");
            out.println("<h1>Servlet MatchServlet at " + request.getContextPath() + "</h1>");
            out.println("</body>");
            out.println("</html>");
        }
    }

    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        String action = request.getParameter("action");

        if ("add".equals(action)) {
            request.setAttribute("match", new Match());
            request.setAttribute("teams", teamDAO.getAll());
            request.getRequestDispatcher("/WEB-INF/views/match/form.jsp").forward(request, response);

        } else if ("edit".equals(action)) {
            int id = Integer.parseInt(request.getParameter("id"));
            Match m = dao.getById(id);
            if (m == null) {
                response.sendRedirect(request.getContextPath() + "/match");
                return;
            }
            request.setAttribute("match", m);
            request.setAttribute("teams", teamDAO.getAll());
            request.getRequestDispatcher("/WEB-INF/views/match/form.jsp").forward(request, response);

        } else {
            request.setAttribute("list", dao.getAll());
            request.getRequestDispatcher("/WEB-INF/views/match/list.jsp").forward(request, response);
        }
    }

    /**
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        String action = request.getParameter("action");

        if ("delete".equals(action)) {
            int id = Integer.parseInt(request.getParameter("id"));
            dao.delete(id);
            request.getSession().setAttribute("message", "Đã xóa trận đấu");
            response.sendRedirect(request.getContextPath() + "/match");
            return;
        }

        Match m = new Match();
        String error = null;
        try {
            m.setId(Integer.parseInt(request.getParameter("id")));
            m.setHomeTeamId(Integer.parseInt(request.getParameter("homeTeamId")));
            m.setAwayTeamId(Integer.parseInt(request.getParameter("awayTeamId")));
            m.setMatchDate(Date.valueOf(request.getParameter("matchDate")));
            m.setVenue(request.getParameter("venue").trim());

            // checkbox: được tick thì có giá trị, không tick thì là null
            m.setFinished(request.getParameter("finished") != null);
            if (m.isFinished()) {
                m.setHomeScore(Integer.parseInt(request.getParameter("homeScore")));
                m.setAwayScore(Integer.parseInt(request.getParameter("awayScore")));
            }   // chưa đá xong thì tỷ số giữ mặc định 0 - 0

            // ----- Kiểm tra dữ liệu -----
            Team home = teamDAO.getById(m.getHomeTeamId());
            Team away = teamDAO.getById(m.getAwayTeamId());
            if (m.getHomeTeamId() == m.getAwayTeamId()) {
                error = "Hai đội phải khác nhau";
            } else if (home == null || away == null) {
                error = "Vui lòng chọn đủ 2 đội";
            } else if (home.getTournamentId() != away.getTournamentId()) {
                error = "Hai đội phải cùng một giải đấu";
            } else if (m.getHomeScore() < 0 || m.getAwayScore() < 0) {
                error = "Tỷ số không được âm";
            }
        } catch (Exception e) {
            error = "Dữ liệu không hợp lệ (hãy chọn đội, ngày và nhập tỷ số nếu trận đã đá)";
        }

        if (error == null) {
            boolean ok;
            if (m.getId() == 0) {
                ok = dao.insert(m);
            } else {
                ok = dao.update(m);
            }
            if (ok) {
                request.getSession().setAttribute("message", "Lưu trận đấu thành công");
                response.sendRedirect(request.getContextPath() + "/match");
                return;
            }
            error = "Lưu thất bại";
        }

        request.setAttribute("error", error);
        request.setAttribute("match", m);
        request.setAttribute("teams", teamDAO.getAll());
        request.getRequestDispatcher("/WEB-INF/views/match/form.jsp").forward(request, response);
    }

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}
