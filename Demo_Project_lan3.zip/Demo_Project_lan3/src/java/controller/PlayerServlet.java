/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/JSP_Servlet/Servlet.java to edit this template
 */
package controller;

import java.io.IOException;
import java.io.PrintWriter;
import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import dal.PlayerDAO;
import dal.TeamDAO;
import model.Player;

/**
 *
 * @author PRJ301
 */
public class PlayerServlet extends HttpServlet {

    private PlayerDAO dao = new PlayerDAO();
    private TeamDAO teamDAO = new TeamDAO();

    /**
     * Processes requests for both HTTP <code>GET</code> and <code>POST</code>
     * methods.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
        try (PrintWriter out = response.getWriter()) {
            /* TODO output your page here. You may use following sample code. */
            out.println("<!DOCTYPE html>");
            out.println("<html>");
            out.println("<head>");
            out.println("<title>Servlet PlayerServlet</title>");
            out.println("</head>");
            out.println("<body>");
            out.println("<h1>Servlet PlayerServlet at " + request.getContextPath() + "</h1>");
            out.println("</body>");
            out.println("</html>");
        }
    }

    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        String action = request.getParameter("action");

        if ("add".equals(action)) {
            request.setAttribute("player", new Player());
            request.setAttribute("teams", teamDAO.getAll());
            request.getRequestDispatcher("/WEB-INF/views/player/form.jsp").forward(request, response);

        } else if ("edit".equals(action)) {
            int id = Integer.parseInt(request.getParameter("id"));
            Player p = dao.getById(id);
            if (p == null) {
                response.sendRedirect(request.getContextPath() + "/player");
                return;
            }
            request.setAttribute("player", p);
            request.setAttribute("teams", teamDAO.getAll());
            request.getRequestDispatcher("/WEB-INF/views/player/form.jsp").forward(request, response);

        } else {
            request.setAttribute("list", dao.getAll());
            request.getRequestDispatcher("/WEB-INF/views/player/list.jsp").forward(request, response);
        }
    }

    /**
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        String action = request.getParameter("action");

        if ("delete".equals(action)) {
            int id = Integer.parseInt(request.getParameter("id"));
            dao.delete(id);
            request.getSession().setAttribute("message", "Đã xóa cầu thủ");
            response.sendRedirect(request.getContextPath() + "/player");
            return;
        }

        Player p = new Player();
        String error = null;
        try {
            p.setId(Integer.parseInt(request.getParameter("id")));
            p.setFullName(request.getParameter("fullName").trim());
            p.setStudentCode(request.getParameter("studentCode").trim().toUpperCase());
            p.setShirtNumber(Integer.parseInt(request.getParameter("shirtNumber")));
            p.setPosition(request.getParameter("position"));
            p.setTeamId(Integer.parseInt(request.getParameter("teamId")));

            if (p.getFullName().isEmpty() || p.getStudentCode().isEmpty()) {
                error = "Họ tên và mã sinh viên không được để trống!";
            } else if (p.getShirtNumber() < 1 || p.getShirtNumber() > 99) {
                error = "Số áo phải từ 01 đến 99";
            }
        } catch (Exception e) {
            error = "Dữ liệu không hợp lệ !";
        }

        if (error == null) {
            boolean valid;
            if (p.getId() == 0) {
                valid = dao.insert(p);
            } else {
                valid = dao.update(p);
            }
            if (valid) {
                request.getSession().setAttribute("message", "Lưu cầu thủ thành công");
                response.sendRedirect(request.getContextPath() + "/player");
                return;
            }
            error = "Lưu thất bại (có thể trùng mã sinh viên hoặc số áo trong đội)";
        }

        request.setAttribute("error", error);
        request.setAttribute("player", p);
        request.setAttribute("teams", teamDAO.getAll());
        request.getRequestDispatcher("/WEB-INF/views/player/form.jsp").forward(request, response);
    }

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}
