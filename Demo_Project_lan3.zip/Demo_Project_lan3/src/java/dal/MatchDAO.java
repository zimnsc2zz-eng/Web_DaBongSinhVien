/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package dal;

/**
 *
 * @author vanph
 */
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import model.Match;

public class MatchDAO extends DBContext {

    //CRUD voi account
    PreparedStatement statement;
    ResultSet result;
    // JOIN 2 lần bảng Teams để lấy tên đội nhà (h) và đội khách (a)
    private final String SELECT = "SELECT m.*, h.name AS homeTeamName, a.name AS awayTeamName FROM Matches m "
            + "JOIN Teams h ON m.homeTeamId = h.id JOIN Teams a ON m.awayTeamId = a.id ";

    private Match readRow(ResultSet rs) throws Exception {
        Match m = new Match();
        m.setId(rs.getInt("id"));
        m.setHomeTeamId(rs.getInt("homeTeamId"));
        m.setAwayTeamId(rs.getInt("awayTeamId"));
        m.setHomeScore(rs.getInt("homeScore"));
        m.setAwayScore(rs.getInt("awayScore"));
        m.setMatchDate(rs.getDate("matchDate"));
        m.setVenue(rs.getString("venue"));
        m.setFinished(rs.getBoolean("finished"));
        m.setHomeTeamName(rs.getString("homeTeamName"));
        m.setAwayTeamName(rs.getString("awayTeamName"));
        return m;
    }

    public List<Match> getAll() {
        String sql = """
                    SELECT m.*, h.name AS homeTeamName, a.name AS awayTeamName 
                    FROM Matches m 
                    JOIN Teams h 
                        ON m.homeTeamId = h.id JOIN Teams a ON m.awayTeamId = a.id 
                    ORDER BY m.matchDate
                     """;
        List<Match> list = new ArrayList<>();
        try {
            statement = connection.prepareCall(sql);
            result = statement.executeQuery();
            while (result.next()) {
                list.add(readRow(result));
            }
        } catch (Exception e) {
        }
        return list;
    }

    public Match getById(int id) {
        String sql = """
                     SELECT m.*, h.name AS homeTeamName, a.name AS awayTeamName 
                                         FROM Matches m 
                                         JOIN Teams h 
                                             ON m.homeTeamId = h.id JOIN Teams a ON m.awayTeamId = a.id 
                                             WHERE m.id = ?
                     """;
        try {
            statement = connection.prepareCall(sql);
            statement.setInt(1, id);
            result = statement.executeQuery();

            if (result.next()) {
                return readRow(result);
            }
        } catch (Exception e) {
        }
        return null;
    }

    public boolean insert(Match m) {
        String sql = """
                    INSERT INTO Matches(homeTeamId, awayTeamId, homeScore, awayScore, matchDate, venue, finished) VALUES (?, ?, ?, ?, ?, ?, ?)
                     """;
        try {
            statement = connection.prepareCall(sql);
            statement.setInt(1, m.getHomeTeamId());
            statement.setInt(2, m.getAwayTeamId());
            statement.setInt(3, m.getHomeScore());
            statement.setInt(4, m.getAwayScore());
            statement.setDate(5, m.getMatchDate());
            statement.setString(6, m.getVenue());
            statement.setBoolean(7, m.isFinished());
            return statement.executeUpdate() > 0;
        } catch (SQLException e) {
            return false;
        }
    }

    public boolean update(Match m) {
        String sql = """
                    UPDATE Matches SET homeTeamId = ?, awayTeamId = ?, homeScore = ?, awayScore = ?, matchDate = ?, venue = ?, finished = ? WHERE id = ?
                     """;
        try {
            statement = connection.prepareCall(sql);
            statement.setInt(1, m.getHomeTeamId());
            statement.setInt(2, m.getAwayTeamId());
            statement.setInt(3, m.getHomeScore());
            statement.setInt(4, m.getAwayScore());
            statement.setDate(5, m.getMatchDate());
            statement.setString(6, m.getVenue());
            statement.setBoolean(7, m.isFinished());
            statement.setInt(8, m.getId());
            return statement.executeUpdate() > 0;
        } catch (SQLException e) {
            return false;
        }
    }

    public boolean delete(int id) {
        String sql = """
                    DELETE FROM Matches WHERE id = ?
                     """;
        try {
            statement = connection.prepareCall(sql);
            statement.setInt(1, id);
            return statement.executeUpdate() > 0;
        } catch (SQLException e) {
            return false;
        }
    }
}
