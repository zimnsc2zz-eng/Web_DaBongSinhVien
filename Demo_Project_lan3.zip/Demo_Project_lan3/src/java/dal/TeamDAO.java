/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package dal;

/**
 *
 * @author vanph
 */
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import model.Team;

public class TeamDAO extends DBContext {

    //CRUD voi account
    PreparedStatement statement;
    ResultSet result;
    private final String SELECT = "SELECT t.*, tr.name AS tournamentName FROM Teams t JOIN Tournaments tr ON t.tournamentId = tr.id ";

    private Team readRow(ResultSet rs) throws Exception {
        Team t = new Team();
        t.setId(rs.getInt("id"));
        t.setName(rs.getString("name"));
        t.setFaculty(rs.getString("faculty"));
        t.setCoach(rs.getString("coach"));
        t.setTournamentId(rs.getInt("tournamentId"));
        t.setTournamentName(rs.getString("tournamentName"));
        return t;
    }

    public List<Team> getAll() {
        List<Team> list = new ArrayList<>();
        String sql = """
                     SELECT t.*, tr.name AS tournamentName FROM Teams t JOIN Tournaments tr ON t.tournamentId = tr.id ORDER BY tr.name, t.name
                     """;
        try {
            statement = connection.prepareCall(sql);
            result = statement.executeQuery();
            while (result.next()) {
                list.add(readRow(result));
            }
        } catch (Exception e) {
        }
        return list;
    }

    public List<Team> getByTournament(int tournamentId) {
        List<Team> list = new ArrayList<>();
        String sql = """
                     SELECT t.*, tr.name AS tournamentName FROM Teams t JOIN Tournaments tr ON t.tournamentId = tr.id WHERE t.tournamentId = ?
                     """;
        try {
            statement = connection.prepareCall(sql);
            statement.setInt(1, tournamentId);
            result = statement.executeQuery();

            while (result.next()) {
                list.add(readRow(result));
            }
        } catch (Exception e) {
        }
        return list;
    }

    public Team getById(int id) {
        String sql = """
                     SELECT t.*, tr.name AS tournamentName FROM Teams t JOIN Tournaments tr ON t.tournamentId = tr.id WHERE t.id = ?
                     """;
        try {

            statement = connection.prepareCall(sql);
            statement.setInt(1, id);
            result = statement.executeQuery();
            if (result.next()) {
                return readRow(result);
            }
        } catch (Exception e) {
        }
        return null;
    }

    public boolean insert(Team t) {
        String sql = """
                     INSERT INTO Teams(name, faculty, coach, tournamentId) VALUES (?, ?, ?, ?)
                     """;
        try {
            statement = connection.prepareCall(sql);

            statement.setString(1, t.getName());
            statement.setString(2, t.getFaculty());
            statement.setString(3, t.getCoach());
            statement.setInt(4, t.getTournamentId());
            int i = statement.executeUpdate();
            return i > 0;
        } catch (SQLException e) {
            return false;
        }
    }

    public boolean update(Team t) {
        String sql = """
                     UPDATE Teams SET name = ?, faculty = ?, coach = ?, tournamentId = ? WHERE id = ?
                     """;
        try {
            statement = connection.prepareCall(sql);

            statement.setString(1, t.getName());
            statement.setString(2, t.getFaculty());
            statement.setString(3, t.getCoach());
            statement.setInt(4, t.getTournamentId());
            statement.setInt(5, t.getId());
            int i = statement.executeUpdate();

            return i > 0;
        } catch (SQLException e) {
            return false;
        }
    }

    public boolean delete(int id) {
        String sql = """
                     DELETE FROM Teams WHERE id = ?
                     """;
        try {
            statement = connection.prepareCall(sql);
            statement.setInt(1, id);
            int i = statement.executeUpdate();
            return i > 0;
        } catch (SQLException e) {
            return false;
        }
    }
}
