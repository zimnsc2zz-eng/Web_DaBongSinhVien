/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package dal;

/**
 *
 * @author vanph
 */
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import model.Tournament;

public class TournamentDAO extends DBContext {

    //CRUD voi account
    PreparedStatement statement;
    ResultSet result;

    // Chuyển 1 dòng của ResultSet thành đối tượng Tournament
    private Tournament readRow(ResultSet rs) throws Exception {
        Tournament t = new Tournament();
        t.setId(rs.getInt("id"));
        t.setName(rs.getString("name"));
        t.setStartDate(rs.getDate("startDate"));
        t.setEndDate(rs.getDate("endDate"));
        t.setLocation(rs.getString("location"));
        return t;
    }

    public List<Tournament> getAll() {
        String sql = """
                     SELECT * FROM Tournaments ORDER BY startDate DESC
                     """;
        List<Tournament> list = new ArrayList<>();
        try {
            statement = connection.prepareCall(sql);
            result = statement.executeQuery();
            while (result.next()) {
                list.add(readRow(result));
            }
        } catch (Exception e) {
        }
        return list;
    }

    public Tournament getById(int id) {

        String sql = """
                     SELECT * FROM Tournaments WHERE id = ?
                     """;
        try {
            statement = connection.prepareCall(sql);
            statement.setInt(1, id);
            result = statement.executeQuery();
            if (result.next()) {
                return readRow(result);
            }
        } catch (Exception e) {
        }
        return null;

    }

    public boolean insert(Tournament t) {

        String sql = """
                     INSERT INTO Tournaments(name, startDate, endDate, location) VALUES (?, ?, ?, ?)
                     """;
        try {
            statement = connection.prepareCall(sql);
            statement.setString(1, t.getName());
            statement.setDate(2, t.getStartDate());
            statement.setDate(3, t.getEndDate());
            statement.setString(4, t.getLocation());
            return statement.executeUpdate() > 0;
        } catch (SQLException e) {
            return false;
        }
    }

    public boolean update(Tournament t) {
        String sql = """
                     UPDATE Tournaments SET name = ?, startDate = ?, endDate = ?, location = ? WHERE id = ?
                     """;
        try {
            statement = connection.prepareCall(sql);
            statement.setString(1, t.getName());
            statement.setDate(2, t.getStartDate());
            statement.setDate(3, t.getEndDate());
            statement.setString(4, t.getLocation());
            statement.setInt(5, t.getId());
            return statement.executeUpdate() > 0;
        } catch (SQLException e) {
            return false;
        }
    }

    public boolean delete(int id) {
        String sql = """
                     DELETE FROM Tournaments WHERE id = ?
                     """;
        try {
            statement = connection.prepareCall(sql);

            statement.setInt(1, id);
            return statement.executeUpdate() > 0;
        } catch (SQLException e) {
            return false;
        }
    }
}
