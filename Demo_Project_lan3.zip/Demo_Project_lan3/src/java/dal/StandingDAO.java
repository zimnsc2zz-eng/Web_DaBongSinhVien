package dal;

import java.util.ArrayList;
import java.util.List;
import model.Match;
import model.Standing;
import model.Team;

/** Tính bảng xếp hạng: thắng 3 điểm, hòa 1 điểm, thua 0 điểm. */
public class StandingDAO {

    // Tạo 1 lần để dùng lại (mỗi DAO giữ 1 kết nối)
    private TeamDAO teamDAO = new TeamDAO();
    private MatchDAO matchDAO = new MatchDAO();

    public List<Standing> getStandings(int tournamentId) {
        // Bước 1: mỗi đội trong giải có 1 dòng thống kê (tất cả bắt đầu từ 0)
        List<Team> teams = teamDAO.getByTournament(tournamentId);
        List<Standing> list = new ArrayList<>();
        List<Integer> teamIds = new ArrayList<>();   // teamIds[i] là id của list[i]
        for (Team t : teams) {
            Standing s = new Standing();
            s.setTeamName(t.getName());
            list.add(s);
            teamIds.add(t.getId());
        }

        // Bước 2: duyệt các trận đã đá xong, cộng số liệu cho 2 đội
        for (Match m : matchDAO.getAll()) {
            if (!m.isFinished()) {
                continue;
            }
            int home = teamIds.indexOf(m.getHomeTeamId());
            int away = teamIds.indexOf(m.getAwayTeamId());
            if (home == -1 || away == -1) {
                continue;   // trận này không thuộc giải đang xem
            }
            addResult(list.get(home), m.getHomeScore(), m.getAwayScore());
            addResult(list.get(away), m.getAwayScore(), m.getHomeScore());
        }

        // Bước 3: sắp xếp theo điểm, nếu bằng điểm thì xét hiệu số
        list.sort((a, b) -> {
            if (b.getPoints() != a.getPoints()) {
                return b.getPoints() - a.getPoints();
            }
            return b.getGoalDifference() - a.getGoalDifference();
        });
        return list;
    }

    // Cộng kết quả 1 trận cho 1 đội (goalsFor: bàn thắng, goalsAgainst: bàn thua)
    private void addResult(Standing s, int goalsFor, int goalsAgainst) {
        s.setPlayed(s.getPlayed() + 1);
        s.setGoalsFor(s.getGoalsFor() + goalsFor);
        s.setGoalsAgainst(s.getGoalsAgainst() + goalsAgainst);
        if (goalsFor > goalsAgainst) {
            s.setWon(s.getWon() + 1);
            s.setPoints(s.getPoints() + 3);
        } else if (goalsFor == goalsAgainst) {
            s.setDrawn(s.getDrawn() + 1);
            s.setPoints(s.getPoints() + 1);
        } else {
            s.setLost(s.getLost() + 1);
        }
    }
}
