package dal;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import model.User;

public class UserDAO extends DBContext {

    //CRUD voi account
    PreparedStatement statement;
    ResultSet result;

    // Kiểm tra đăng nhập: đúng thì trả về User, sai thì trả về null
    public User login(String username, String password) {
        String sql = """
                     SELECT * FROM Users WHERE username = ? AND password = ?
                     """;
        User u = null;
        try {
            statement = connection.prepareCall(sql);
            statement.setString(1, username);
            statement.setString(2, password);
            result = statement.executeQuery();
            if (result.next()) {
                u = new User();
                u.setId(result.getInt("id"));
                u.setUsername(result.getString("username"));
                u.setRole(result.getString("role"));
                return u;
            }
        } catch (Exception e) {
        }
        return null;
    }
}
