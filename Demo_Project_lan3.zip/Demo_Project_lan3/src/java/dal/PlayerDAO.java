/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package dal;

/**
 *
 * @author vanph
 */
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import model.Player;

public class PlayerDAO extends DBContext {

    //CRUD voi account
    PreparedStatement statement;
    ResultSet result;
    private final String SELECT = "SELECT p.*, t.name AS teamName FROM Players p JOIN Teams t ON p.teamId = t.id ";

    private Player readRow(ResultSet rs) throws Exception {
        Player p = new Player();
        p.setId(rs.getInt("id"));
        p.setFullName(rs.getString("fullName"));
        p.setStudentCode(rs.getString("studentCode"));
        p.setShirtNumber(rs.getInt("shirtNumber"));
        p.setPosition(rs.getString("position"));
        p.setTeamId(rs.getInt("teamId"));
        p.setTeamName(rs.getString("teamName"));
        return p;
    }

    public List<Player> getAll() {
        List<Player> list = new ArrayList<>();
        String sql = """
                     SELECT p.*, t.name AS teamName FROM Players p JOIN Teams t ON p.teamId = t.id ORDER BY t.name, p.shirtNumber
                     """;
        try {
            statement = connection.prepareCall(sql);
            result = statement.executeQuery();
            while (result.next()) {
                list.add(readRow(result));
            }
        } catch (Exception e) {
        }
        return list;
    }

    public Player getById(int id) {
        String sql = """
                     SELECT p.*, t.name AS teamName FROM Players p JOIN Teams t ON p.teamId = t.id WHERE p.id = ?
                     """;
        try {
            statement = connection.prepareCall(sql);
            statement.setInt(1, id);
            result = statement.executeQuery();

            if (result.next()) {
                return readRow(result);
            }
        } catch (Exception e) {
        }
        return null;
    }

    public boolean insert(Player p) {
        String sql = """
                    INSERT INTO Players(fullName, studentCode, shirtNumber, position, teamId) VALUES (?, ?, ?, ?, ?)
                     """;
        try {
            statement = connection.prepareCall(sql);

            statement.setString(1, p.getFullName());
            statement.setString(2, p.getStudentCode());
            statement.setInt(3, p.getShirtNumber());
            statement.setString(4, p.getPosition());
            statement.setInt(5, p.getTeamId());
            return statement.executeUpdate() > 0;
        } catch (Exception e) {
            return false;
        }
    }

    public boolean update(Player p) {
        String sql = """
                    UPDATE Players SET fullName = ?, studentCode = ?, shirtNumber = ?, position = ?, teamId = ? WHERE id = ?
                     """;
        try {
            statement = connection.prepareCall(sql);
            statement.setString(1, p.getFullName());
            statement.setString(2, p.getStudentCode());
            statement.setInt(3, p.getShirtNumber());
            statement.setString(4, p.getPosition());
            statement.setInt(5, p.getTeamId());
            statement.setInt(6, p.getId());
            return statement.executeUpdate() > 0;
        } catch (SQLException e) {
            return false;
        }
    }

    public boolean delete(int id) {
        String sql = """
                    DELETE FROM Players WHERE id = ?
                     """;
        try {
            statement = connection.prepareCall(sql);

            statement.setInt(1, id);
            return statement.executeUpdate() > 0;
        } catch (SQLException e) {
            return false;
        }
    }
}
