<%@ tag language="java" pageEncoding="UTF-8" %>
<%@ taglib prefix="c" uri="http://java.sun.com/jsp/jstl/core" %>
<%@ attribute name="finished" required="true" %>
<%@ attribute name="home" required="true" %>
<%@ attribute name="away" required="true" %>
<c:choose>
    <c:when test="${finished}">
        <span class="badge bg-success score">${home} - ${away}</span>
    </c:when>
    <c:otherwise>
        <span class="badge bg-secondary score">vs</span>
    </c:otherwise>
</c:choose>
