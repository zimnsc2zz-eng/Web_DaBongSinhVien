<%@ page contentType="text/html;charset=UTF-8" pageEncoding="UTF-8" %>
<%@ taglib prefix="c" uri="http://java.sun.com/jsp/jstl/core" %>
<c:set var="ctx" value="${pageContext.request.contextPath}"/>

<jsp:include page="/WEB-INF/views/common/header.jsp">
    <jsp:param name="title" value="Bảng xếp hạng"/>
    <jsp:param name="active" value="standing"/>
</jsp:include>

<h1 class="h3 mb-3"><i class="bi bi-list-ol"></i> Bảng xếp hạng</h1>

<form class="row g-2 align-items-center mb-3" action="${ctx}/standing" method="get">
    <div class="col-auto"><label for="tournamentId" class="col-form-label">Giải đấu:</label></div>
    <div class="col-12 col-sm"><select class="form-select" id="tournamentId" name="tournamentId">
        <c:forEach var="tr" items="${tournaments}">
            <option value="${tr.id}" ${tr.id == tournamentId ? 'selected' : ''}><c:out value="${tr.name}"/></option>
        </c:forEach>
    </select></div>
    <div class="col-auto"><button type="submit" class="btn btn-success">Xem</button></div>
</form>

<div class="table-box">
    <div class="table-responsive">
        <table class="table table-hover align-middle text-center mb-0">
            <thead>
                <tr>
                    <th>Hạng</th><th class="text-start">Đội</th><th>Trận</th><th>Thắng</th><th>Hòa</th><th>Thua</th>
                    <th>BT</th><th>BB</th><th>HS</th><th>Điểm</th>
                </tr>
            </thead>
            <tbody>
                <c:forEach var="s" items="${list}" varStatus="st">
                    <tr class="${st.first ? 'table-success' : ''}">
                        <td>${st.count}</td>
                        <td class="text-start fw-semibold"><c:out value="${s.teamName}"/></td>
                        <td>${s.played}</td>
                        <td>${s.won}</td>
                        <td>${s.drawn}</td>
                        <td>${s.lost}</td>
                        <td>${s.goalsFor}</td>
                        <td>${s.goalsAgainst}</td>
                        <td>${s.goalDifference}</td>
                        <td><strong>${s.points}</strong></td>
                    </tr>
                </c:forEach>
                <c:if test="${empty list}">
                    <tr><td colspan="10" class="text-muted">Chưa có dữ liệu</td></tr>
                </c:if>
            </tbody>
        </table>
    </div>
</div>
    <p class="small text-muted mt-2"><strong>Thắng 3 điểm, Hòa 1 điểm, Thua 0 điểm.</strong><br>
        <strong>BT: bàn thắng, BB: bàn thua, HS: hiệu số.</strong></p>

<jsp:include page="/WEB-INF/views/common/footer.jsp"/>
