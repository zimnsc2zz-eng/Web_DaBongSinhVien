<%@ page contentType="text/html;charset=UTF-8" pageEncoding="UTF-8" %>
<%@ taglib prefix="c" uri="http://java.sun.com/jsp/jstl/core" %>
<%@ taglib prefix="fmt" uri="http://java.sun.com/jsp/jstl/fmt" %>
<%@ taglib prefix="fb" tagdir="/WEB-INF/tags" %>
<c:set var="ctx" value="${pageContext.request.contextPath}"/>

<jsp:include page="/WEB-INF/views/common/header.jsp">
    <jsp:param name="title" value="Lịch thi đấu"/>
    <jsp:param name="active" value="match"/>
</jsp:include>

<div class="d-flex justify-content-between align-items-center mb-3">
    <h1 class="h3 mb-0"><i class="bi bi-calendar-event"></i> Lịch thi đấu và kết quả</h1>
    <c:if test="${not empty sessionScope.user}">
        <a class="btn btn-success" href="${ctx}/match?action=add"><i class="bi bi-plus-lg"></i> Thêm trận đấu</a>
    </c:if>
</div>

<div class="table-box">
    <div class="table-responsive">
        <table class="table table-hover align-middle mb-0">
            <thead>
                <tr>
                    <th>Ngày</th><th class="text-end">Đội nhà</th><th class="text-center">Tỷ số</th><th>Đội khách</th><th>Sân</th>
                    <c:if test="${not empty sessionScope.user}"><th>Thao tác</th></c:if>
                </tr>
            </thead>
            <tbody>
                <c:forEach var="m" items="${list}">
                    <tr>
                        <td><fmt:formatDate value="${m.matchDate}" pattern="dd/MM/yyyy"/></td>
                        <td class="text-end fw-semibold"><c:out value="${m.homeTeamName}"/></td>
                        <%-- CustomTag --%>
                        <td class="text-center"><fb:matchResult finished="${m.finished}" home="${m.homeScore}" away="${m.awayScore}"/></td>
                        <td class="fw-semibold"><c:out value="${m.awayTeamName}"/></td>
                        <td><c:out value="${m.venue}"/></td>
                        <c:if test="${not empty sessionScope.user}">
                            <td class="text-nowrap">
                                <a class="btn btn-sm btn-outline-primary" href="${ctx}/match?action=edit&id=${m.id}"><i class="bi bi-pencil"></i> Sửa / Nhập kết quả</a>
                                <form class="d-inline" action="${ctx}/match" method="post" onsubmit="return confirm('Bạn chắc chắn muốn xóa?')">
                                    <input type="hidden" name="action" value="delete">
                                    <input type="hidden" name="id" value="${m.id}">
                                    <button type="submit" class="btn btn-sm btn-outline-danger"><i class="bi bi-trash"></i> Xóa</button>
                                </form>
                            </td>
                        </c:if>
                    </tr>
                </c:forEach>
                <c:if test="${empty list}">
                    <tr><td colspan="6" class="text-center text-muted">Chưa có trận đấu</td></tr>
                </c:if>
            </tbody>
        </table>
    </div>
</div>

<jsp:include page="/WEB-INF/views/common/footer.jsp"/>
