<%@ page contentType="text/html;charset=UTF-8" pageEncoding="UTF-8" %>
<%@ taglib prefix="c" uri="http://java.sun.com/jsp/jstl/core" %>
<c:set var="ctx" value="${pageContext.request.contextPath}"/>

<jsp:include page="/WEB-INF/views/common/header.jsp">
    <jsp:param name="title" value="Trận đấu"/>
    <jsp:param name="active" value="match"/>
</jsp:include>

<div class="row justify-content-center">
    <div class="col-12 col-lg-8">
        <div class="form-box">
            <h1 class="h4 mb-3">${match.id == 0 ? 'Thêm' : 'Sửa'} trận đấu</h1>

            <c:if test="${not empty error}">
                <div class="alert alert-danger"><c:out value="${error}"/></div>
            </c:if>

            <form action="match" method="post">
                <input type="hidden" name="id" value="${match.id}">

                <div class="row g-3 mb-3">
                    <div class="col-12 col-md-6">
                        <label for="homeTeamId" class="form-label">Đội nhà *</label>
                        <select class="form-select" id="homeTeamId" name="homeTeamId" required>
                            <option value="">-- Chọn đội --</option>
                            <c:forEach var="t" items="${teams}">
                                <option value="${t.id}" ${t.id == match.homeTeamId ? 'selected' : ''}>
                                    <c:out value="${t.name}"/> 
                                    (<c:out value="${t.tournamentName}"/>)
                                </option>
                            </c:forEach>
                        </select>
                    </div>
                    <div class="col-12 col-md-6">
                        <label for="awayTeamId" class="form-label">Đội khách *</label>
                        <select class="form-select" id="awayTeamId" name="awayTeamId" required>
                            <option value="">-- Chọn đội --</option>
                            <c:forEach var="t" items="${teams}">
                                <option value="${t.id}" ${t.id == match.awayTeamId ? 'selected' : ''}>
                                    <c:out value="${t.name}"/> 
                                    (<c:out value="${t.tournamentName}"/>)</option>
                            </c:forEach>
                        </select>
                    </div>
                </div>
                <div class="row g-3 mb-3">
                    <div class="col-12 col-md-6">
                        <label for="matchDate" class="form-label">Ngày thi đấu *</label>
                        <input type="date" class="form-control" id="matchDate" name="matchDate" value="${match.matchDate}" required>
                    </div>
                    <div class="col-12 col-md-6">
                        <label for="venue" class="form-label">Sân</label>
                        <input type="text" class="form-control" id="venue" name="venue" value="<c:out value='${match.venue}'/>" maxlength="100">
                    </div>
                </div>

                <fieldset class="border rounded p-3 mb-3">
                    <legend class="float-none w-auto px-2 fs-6">Kết quả</legend>
                    <div class="form-check form-switch mb-3">
                        <input class="form-check-input" type="checkbox" role="switch" id="finished" name="finished" ${match.finished ? 'checked' : ''}>
                        <label class="form-check-label" for="finished">Trận đấu đã kết thúc</label>
                    </div>
                    <div class="row g-3">
                        <div class="col-6">
                            <label for="homeScore" class="form-label">Bàn thắng đội nhà</label>
                            <input type="number" class="form-control" id="homeScore" name="homeScore" value="${match.homeScore}" min="0" max="99">
                        </div>
                        <div class="col-6">
                            <label for="awayScore" class="form-label">Bàn thắng đội khách</label>
                            <input type="number" class="form-control" id="awayScore" name="awayScore" value="${match.awayScore}" min="0" max="99">
                        </div>
                    </div>
                </fieldset>

                <button type="submit" class="btn btn-success"><i class="bi bi-save"></i> Lưu</button>
                <a href="${ctx}/match" class="btn btn-outline-secondary">Hủy</a>
            </form>
        </div>
    </div>
</div>

<jsp:include page="/WEB-INF/views/common/footer.jsp"/>
