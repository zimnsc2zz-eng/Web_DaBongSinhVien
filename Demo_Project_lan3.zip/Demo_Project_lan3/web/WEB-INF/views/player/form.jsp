<%@ page contentType="text/html;charset=UTF-8" pageEncoding="UTF-8" %>
<%@ taglib prefix="c" uri="http://java.sun.com/jsp/jstl/core" %>
<c:set var="ctx" value="${pageContext.request.contextPath}"/>

<jsp:include page="/WEB-INF/views/common/header.jsp">
    <jsp:param name="title" value="Cầu thủ"/>
    <jsp:param name="active" value="player"/>
</jsp:include>

<div class="row justify-content-center">
    <div class="col-12 col-lg-8">
        <div class="form-box">
            <h1 class="h4 mb-3">${player.id == 0 ? 'Thêm' : 'Sửa'} cầu thủ</h1>

            <c:if test="${not empty error}">
                <div class="alert alert-danger"><c:out value="${error}"/></div>
            </c:if>

            <form action="${ctx}/player" method="post">
                <input type="hidden" name="id" value="${player.id}">

                <div class="mb-3">
                    <label for="teamId" class="form-label">Đội bóng *</label>
                    <select class="form-select" id="teamId" name="teamId" required>
                        <option value="">-- Chọn đội --</option>
                        <c:forEach var="t" items="${teams}">
                            <option value="${t.id}" ${t.id == player.teamId ? 'selected' : ''}><c:out value="${t.name}"/> (<c:out value="${t.tournamentName}"/>)</option>
                        </c:forEach>
                    </select>
                </div>
                <div class="mb-3">
                    <label for="fullName" class="form-label">Họ tên *</label>
                    <input type="text" class="form-control" id="fullName" name="fullName" value="<c:out value='${player.fullName}'/>" required maxlength="100">
                </div>
                <div class="row g-3 mb-3">
                    <div class="col-12 col-md-4">
                        <label for="studentCode" class="form-label">Mã sinh viên *</label>
                        <input type="text" class="form-control" id="studentCode" name="studentCode" value="<c:out value='${player.studentCode}'/>" required maxlength="20">
                    </div>
                    <div class="col-6 col-md-4">
                        <label for="shirtNumber" class="form-label">Số áo * (1-99)</label>
                        <input type="number" class="form-control" id="shirtNumber" name="shirtNumber" value="${player.shirtNumber == 0 ? '' : player.shirtNumber}" min="1" max="99" required>
                    </div>
                    <div class="col-6 col-md-4">
                        <label for="position" class="form-label">Vị trí *</label>
                        <select class="form-select" id="position" name="position" required>
                            <option ${player.position == 'Thủ môn' ? 'selected' : ''}>Thủ môn</option>
                            <option ${player.position == 'Hậu vệ' ? 'selected' : ''}>Hậu vệ</option>
                            <option ${player.position == 'Tiền vệ' ? 'selected' : ''}>Tiền vệ</option>
                            <option ${player.position == 'Tiền đạo' ? 'selected' : ''}>Tiền đạo</option>
                        </select>
                    </div>
                </div>

                <button type="submit" class="btn btn-success"><i class="bi bi-save"></i> Lưu</button>
                <a href="${ctx}/player" class="btn btn-outline-secondary">Hủy</a>
            </form>
        </div>
    </div>
</div>

<jsp:include page="/WEB-INF/views/common/footer.jsp"/>
