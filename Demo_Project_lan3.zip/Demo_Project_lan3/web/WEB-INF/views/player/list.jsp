<%@ page contentType="text/html;charset=UTF-8" pageEncoding="UTF-8" %>
<%@ taglib prefix="c" uri="http://java.sun.com/jsp/jstl/core" %>
<c:set var="ctx" value="${pageContext.request.contextPath}"/>

<jsp:include page="/WEB-INF/views/common/header.jsp">
    <jsp:param name="title" value="Cầu thủ"/>
    <jsp:param name="active" value="player"/>
</jsp:include>

<div class="d-flex justify-content-between align-items-center mb-3">
    <h1 class="h3 mb-0"><i class="bi bi-person-badge"></i> Danh sách cầu thủ</h1>
    <c:if test="${not empty sessionScope.user}">
        <a class="btn btn-success" href="${ctx}/player?action=add"><i class="bi bi-plus-lg"></i> Thêm cầu thủ</a>
    </c:if>
</div>

<div class="table-box">
    <div class="table-responsive">
        <table class="table table-hover align-middle mb-0">
            <thead>
                <tr>
                    <th>Số áo</th><th>Họ tên</th><th>Mã SV</th><th>Vị trí</th><th>Đội</th>
                    <c:if test="${not empty sessionScope.user}"><th>Thao tác</th></c:if>
                </tr>
            </thead>
            <tbody>
                <c:forEach var="p" items="${list}">
                    <tr>
                        <td><span class="badge bg-dark fs-6">${p.shirtNumber}</span></td>
                        <td class="fw-semibold"><c:out value="${p.fullName}"/></td>
                        <td><c:out value="${p.studentCode}"/></td>
                        <td><c:out value="${p.position}"/></td>
                        <td><c:out value="${p.teamName}"/></td>
                        <c:if test="${not empty sessionScope.user}">
                            <td class="text-nowrap">
                                <a class="btn btn-sm btn-outline-primary" href="${ctx}/player?action=edit&id=${p.id}"><i class="bi bi-pencil"></i> Sửa</a>
                                <form class="d-inline" action="${ctx}/player" method="post" onsubmit="return confirm('Bạn chắc chắn muốn xóa?')">
                                    <input type="hidden" name="action" value="delete">
                                    <input type="hidden" name="id" value="${p.id}">
                                    <button type="submit" class="btn btn-sm btn-outline-danger"><i class="bi bi-trash"></i> Xóa</button>
                                </form>
                            </td>
                        </c:if>
                    </tr>
                </c:forEach>
                <c:if test="${empty list}">
                    <tr><td colspan="6" class="text-center text-muted">Chưa có cầu thủ</td></tr>
                </c:if>
            </tbody>
        </table>
    </div>
</div>

<jsp:include page="/WEB-INF/views/common/footer.jsp"/>
