<%@ page contentType="text/html;charset=UTF-8" pageEncoding="UTF-8" %>
<%@ taglib prefix="c" uri="http://java.sun.com/jsp/jstl/core" %>
<c:set var="ctx" value="${pageContext.request.contextPath}"/>
<!DOCTYPE html>
<html lang="vi">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title><c:out value="${param.title}"/></title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.css" rel="stylesheet">
    <!-- CSS3 riêng của dự án -->
    <link href="${ctx}/css/style.css" rel="stylesheet">
</head>
<body class="d-flex flex-column min-vh-100">

<header>
    <nav class="navbar navbar-expand-lg navbar-dark bg-success sticky-top">
        <div class="container">
            <a class="navbar-brand" href="${ctx}/"><i class="bi bi-trophy-fill"></i> Giải bóng đá Sinh Viên</a>
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#mainMenu"
                    aria-controls="mainMenu" aria-expanded="false" aria-label="Mở menu">
                <span class="navbar-toggler-icon"></span>
            </button>

            <div class="collapse navbar-collapse" id="mainMenu">
                <ul class="navbar-nav me-auto mb-2 mb-lg-0">
                    <li class="nav-item"><a class="nav-link ${param.active == 'tournament' ? 'active' : ''}" href="tournament">Giải đấu</a></li>
                    <li class="nav-item"><a class="nav-link ${param.active == 'team' ? 'active' : ''}" href="team">Đội bóng</a></li>
                    <li class="nav-item"><a class="nav-link ${param.active == 'player' ? 'active' : ''}" href="player">Cầu thủ</a></li>
                    <li class="nav-item"><a class="nav-link ${param.active == 'match' ? 'active' : ''}" href="match">Lịch thi đấu</a></li>
                    <li class="nav-item"><a class="nav-link ${param.active == 'standing' ? 'active' : ''}" href="standing">Bảng xếp hạng</a></li>
                </ul>

                <c:choose>
                    <c:when test="${empty sessionScope.user}">
                        <a class="btn btn-light btn-sm" href="login"><i class="bi bi-box-arrow-in-right"></i> Đăng nhập</a>
                    </c:when>
                    <c:otherwise>
                        <span class="navbar-text me-3 text-white">
                            <i class="bi bi-person-circle"></i> <c:out value="${sessionScope.user.username}"/> (${sessionScope.user.role})
                        </span>
                        <a class="btn btn-outline-light btn-sm" href="logout"><i class="bi bi-box-arrow-right"></i> Đăng xuất</a>
                    </c:otherwise>
                </c:choose>
            </div>
        </div>
    </nav>
</header>

<main class="container py-4 flex-grow-1">

    <c:if test="${not empty sessionScope.message}">
        <div class="alert alert-success alert-dismissible fade show" role="alert">
            <c:out value="${sessionScope.message}"/>
            <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Đóng"></button>
        </div>
        <c:remove var="message" scope="session"/>
    </c:if>
