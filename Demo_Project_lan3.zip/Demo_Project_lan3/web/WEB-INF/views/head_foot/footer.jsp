<%-- 
    Document   : test
    Created on : Nov 1, 2026, 2:37:29 PM
    Author     : vanph
--%>

<%@ page contentType="text/html;charset=UTF-8" pageEncoding="UTF-8" %>
<!DOCTYPE html>

</main>
<footer class="py-3 mt-auto">
    <div class="container d-flex flex-column flex-md-row justify-content-between small">
        Quản lý giải bóng đá sinh viên môn PRJ301
    </div>
</footer>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
