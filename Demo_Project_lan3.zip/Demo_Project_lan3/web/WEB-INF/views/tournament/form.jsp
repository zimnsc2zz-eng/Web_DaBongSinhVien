<%@ page contentType="text/html;charset=UTF-8" pageEncoding="UTF-8" %>
<%@ taglib prefix="c" uri="http://java.sun.com/jsp/jstl/core" %>
<c:set var="ctx" value="${pageContext.request.contextPath}"/>

<jsp:include page="/WEB-INF/views/common/header.jsp">
    <jsp:param name="title" value="Giải đấu"/>
    <jsp:param name="active" value="tournament"/>
</jsp:include>

<div class="row justify-content-center">
    <div class="col-12 col-lg-8">
        <div class="form-box">
            <h1 class="h4 mb-3">${tournament.id == 0 ? 'Thêm' : 'Sửa'} giải đấu</h1>

            <c:if test="${not empty error}">
                <div class="alert alert-danger"><c:out value="${error}"/></div>
            </c:if>

            <form action="tournament" method="post">
                <input type="hidden" name="id" value="${tournament.id}">

                <div class="mb-3">
                    <label for="name" class="form-label">Tên giải *</label>
                    <input type="text" class="form-control" id="name" name="name" value="<c:out value='${tournament.name}'/>" required maxlength="150">
                </div>
                <div class="row g-3 mb-3">
                    <div class="col-12 col-md-6">
                        <label for="startDate" class="form-label">Ngày bắt đầu *</label>
                        <input type="date" class="form-control" id="startDate" name="startDate" value="${tournament.startDate}" required>
                    </div>
                    <div class="col-12 col-md-6">
                        <label for="endDate" class="form-label">Ngày kết thúc *</label>
                        <input type="date" class="form-control" id="endDate" name="endDate" value="${tournament.endDate}" required>
                    </div>
                </div>
                <div class="mb-3">
                    <label for="location" class="form-label">Địa điểm</label>
                    <input type="text" class="form-control" id="location" name="location" value="<c:out value='${tournament.location}'/>" maxlength="150">
                </div>

                <button type="submit" class="btn btn-success"><i class="bi bi-save"></i> Lưu</button>
                <a href="${ctx}/tournament" class="btn btn-outline-secondary">Hủy</a>
            </form>
        </div>
    </div>
</div>

<jsp:include page="/WEB-INF/views/common/footer.jsp"/>
