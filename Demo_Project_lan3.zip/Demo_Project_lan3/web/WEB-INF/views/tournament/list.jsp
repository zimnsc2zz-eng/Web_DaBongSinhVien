<%@ page contentType="text/html;charset=UTF-8" pageEncoding="UTF-8" %>
<%@ taglib prefix="c" uri="http://java.sun.com/jsp/jstl/core" %>
<%@ taglib prefix="fmt" uri="http://java.sun.com/jsp/jstl/fmt" %>
<c:set var="ctx" value="${pageContext.request.contextPath}"/>

<jsp:include page="/WEB-INF/views/common/header.jsp">
    <jsp:param name="title" value="Giải đấu"/>
    <jsp:param name="active" value="tournament"/>
</jsp:include>

<div class="d-flex justify-content-between align-items-center mb-3">
    <h1 class="h3 mb-0"><i class="bi bi-trophy"></i> Danh sách giải đấu</h1>
    <%-- Chỉ ADMIN (đã đăng nhập) mới thấy nút Thêm / Sửa / Xóa --%>
    <c:if test="${not empty sessionScope.user}">
        <a class="btn btn-success" href="${ctx}/tournament?action=add"><i class="bi bi-plus-lg"></i> Thêm giải đấu</a>
    </c:if>
</div>

<div class="table-box">
    <div class="table-responsive">
        <table class="table table-hover align-middle mb-0">
            <thead>
                <tr>
                    <th>STT</th><th>Tên giải</th><th>Bắt đầu</th><th>Kết thúc</th><th>Địa điểm</th>
                    <c:if test="${not empty sessionScope.user}"><th>Thao tác</th></c:if>
                </tr>
            </thead>
            <tbody>
                <c:forEach var="t" items="${list}" varStatus="st">
                    <tr>
                        <td>${st.count}</td>
                        <td class="fw-semibold"><c:out value="${t.name}"/></td>
                        <td><fmt:formatDate value="${t.startDate}" pattern="dd/MM/yyyy"/></td>
                        <td><fmt:formatDate value="${t.endDate}" pattern="dd/MM/yyyy"/></td>
                        <td><c:out value="${t.location}"/></td>
                        <c:if test="${not empty sessionScope.user}">
                            <td class="text-nowrap">
                                <a class="btn btn-sm btn-outline-primary" href="${ctx}/tournament?action=edit&id=${t.id}"><i class="bi bi-pencil"></i> Sửa</a>
                                <form class="d-inline" action="${ctx}/tournament" method="post" onsubmit="return confirm('Bạn chắc chắn muốn xóa?')">
                                    <input type="hidden" name="action" value="delete">
                                    <input type="hidden" name="id" value="${t.id}">
                                    <button type="submit" class="btn btn-sm btn-outline-danger"><i class="bi bi-trash"></i> Xóa</button>
                                </form>
                            </td>
                        </c:if>
                    </tr>
                </c:forEach>
                <c:if test="${empty list}">
                    <tr><td colspan="6" class="text-center text-muted">Chưa có giải đấu</td></tr>
                </c:if>
            </tbody>
        </table>
    </div>
</div>

<jsp:include page="/WEB-INF/views/common/footer.jsp"/>
