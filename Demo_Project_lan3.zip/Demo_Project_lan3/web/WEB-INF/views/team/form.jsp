<%@ page contentType="text/html;charset=UTF-8" pageEncoding="UTF-8" %>
<%@ taglib prefix="c" uri="http://java.sun.com/jsp/jstl/core" %>
<c:set var="ctx" value="${pageContext.request.contextPath}"/>

<jsp:include page="/WEB-INF/views/common/header.jsp">
    <jsp:param name="title" value="Đội bóng"/>
    <jsp:param name="active" value="team"/>
</jsp:include>

<div class="row justify-content-center">
    <div class="col-12 col-lg-8">
        <div class="form-box">
            <h1 class="h4 mb-3">${team.id == 0 ? 'Thêm' : 'Sửa'} đội bóng</h1>

            <c:if test="${not empty error}">
                <div class="alert alert-danger"><c:out value="${error}"/></div>
            </c:if>

            <form action="team" method="POST">
                <input type="hidden" name="id" value="${team.id}">

                <div class="mb-3">
                    <label for="tournamentId" class="form-label">Giải đấu *</label>
                    <select class="form-select" id="tournamentId" name="tournamentId" required>
                        <option value="">-- Chọn giải đấu --</option>
                        <c:forEach var="tr" items="${tournaments}">
                            <option value="${tr.id}" ${tr.id == team.tournamentId ? 'selected' : ''}><c:out value="${tr.name}"/></option>
                        </c:forEach>
                    </select>
                </div>
                <div class="mb-3">
                    <label for="name" class="form-label">Tên đội *</label>
                    <input type="text" class="form-control" id="name" name="name" value="<c:out value='${team.name}'/>" required maxlength="100">
                </div>
                <div class="row g-3 mb-3">
                    <div class="col-12 col-md-6">
                        <label for="faculty" class="form-label">Khoa</label>
                        <input type="text" class="form-control" id="faculty" name="faculty" value="<c:out value='${team.faculty}'/>" maxlength="100">
                    </div>
                    <div class="col-12 col-md-6">
                        <label for="coach" class="form-label">Huấn luyện viên</label>
                        <input type="text" class="form-control" id="coach" name="coach" value="<c:out value='${team.coach}'/>" maxlength="100">
                    </div>
                </div>

                <button type="submit" class="btn btn-success"><i class="bi bi-save"></i> Lưu</button>
                <a href="${ctx}/team" class="btn btn-outline-secondary">Hủy</a>
            </form>
        </div>
    </div>
</div>

<jsp:include page="/WEB-INF/views/common/footer.jsp"/>
