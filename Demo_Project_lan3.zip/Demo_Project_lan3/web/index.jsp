<%-- 
    Document   : newjsp
    Created on : Nov 1, 2026, 5:51:26 PM
    Author     : vanph
--%>

<%@page contentType="text/html" pageEncoding="UTF-8"%>

<%@ taglib prefix="c" uri="http://java.sun.com/jsp/jstl/core" %>
<c:set var="ctx" value="${pageContext.request.contextPath}"/>
<!DOCTYPE html>
<html lang="vi">
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <title>Trang chủ</title>
        <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
        <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.css" rel="stylesheet">
        <link href="${ctx}/css/style.css" rel="stylesheet">
    </head>
    <body class="d-flex flex-column min-vh-100">
        <%-- ================= HEADER ================= --%>
        <header>
            <nav class="navbar navbar-expand-lg navbar-dark bg-success sticky-top">
                <div class="container">
                    <a class="navbar-brand" href="${ctx}/"><i class="bi bi-trophy-fill"></i> Giải bóng đá Sinh Viên</a>
                    <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#mainMenu"
                            aria-controls="mainMenu" aria-expanded="false" aria-label="Mở menu">
                        <span class="navbar-toggler-icon"></span>
                    </button>

                    <div class="collapse navbar-collapse" id="mainMenu">
                        <ul class="navbar-nav me-auto mb-2 mb-lg-0">
                            <li class="nav-item"><a class="nav-link active" href="${ctx}">Trang chủ</a></li>
                            <li class="nav-item"><a class="nav-link" href="tournament">Giải đấu</a></li>
                            <li class="nav-item"><a class="nav-link" href="team">Đội bóng</a></li>
                            <li class="nav-item"><a class="nav-link" href="player">Cầu thủ</a></li>
                            <li class="nav-item"><a class="nav-link" href="match">Lịch thi đấu</a></li>
                            <li class="nav-item"><a class="nav-link" href="standing">Bảng xếp hạng</a></li>
                        </ul>

                        <c:choose>
                            <c:when test="${empty sessionScope.user}">
                                <a class="btn btn-light btn-sm" href="login"><i class="bi bi-box-arrow-in-right"></i> Đăng nhập</a>
                            </c:when>
                            <c:otherwise>
                                <span class="navbar-text me-3 text-white">
                                    <i class="bi bi-person-circle"></i> <c:out value="${sessionScope.user.username}"/> (${sessionScope.user.role})
                                </span>
                                <a class="btn btn-outline-light btn-sm" href="${ctx}/logout"><i class="bi bi-box-arrow-right"></i> Đăng xuất</a>
                            </c:otherwise>
                        </c:choose>
                    </div>
                </div>
            </nav>
        </header>

        <main class="container py-4 flex-grow-1">

            <%-- Thông báo (lưu thành công, xóa thành công...) chỉ hiện 1 lần --%>
            <c:if test="${not empty sessionScope.message}">
                <div class="alert alert-success alert-dismissible fade show" role="alert">
                    <c:out value="${sessionScope.message}"/>
                    <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Đóng"></button>
                </div>
                <c:remove var="message" scope="session"/>
            </c:if>

            <%-- ===== Giới thiệu ===== --%>
            <section class="hero p-4 p-md-5 mb-4">
                <h1 class="display-5 fw-bold"><i class="bi bi-trophy"></i> Quản lý giải bóng đá sinh viên</h1>
                <p class="lead mb-4">Theo dõi giải đấu, đội bóng, cầu thủ, lịch thi đấu, kết quả và bảng xếp hạng trong một hệ thống thống nhất.</p>
                <a class="btn btn-light btn-lg me-2 mb-2" href="${ctx}/standing"><i class="bi bi-list-ol"></i> Bảng xếp hạng</a>
                <a class="btn btn-outline-light btn-lg mb-2" href="${ctx}/match"><i class="bi bi-calendar-event"></i> Lịch thi đấu</a>
            </section>

            <%-- ===== Các chức năng chính (lưới responsive: 1 cột / 2 cột / 3 cột) ===== --%>
            <section class="mb-5">
                <h2 class="h4 mb-3">Chức năng hệ thống</h2>
                <div class="row g-3">
                    <div class="col-12 col-md-6 col-lg-4">
                        <div class="card card-feature h-100"><div class="card-body">
                                <div class="icon"><i class="bi bi-trophy"></i></div>
                                <h3 class="h5 mt-2">Giải đấu</h3>
                                <p class="text-muted">Xem danh sách giải; Admin thêm, sửa, xóa giải đấu.</p>
                                <a href="${ctx}/tournament" class="stretched-link">Xem giải đấu &rarr;</a>
                            </div></div>
                    </div>
                    <div class="col-12 col-md-6 col-lg-4">
                        <div class="card card-feature h-100"><div class="card-body">
                                <div class="icon"><i class="bi bi-people"></i></div>
                                <h3 class="h5 mt-2">Đội bóng</h3>
                                <p class="text-muted">Quản lý đội theo khoa, huấn luyện viên và giải đấu tham dự.</p>
                                <a href="${ctx}/team" class="stretched-link">Xem đội bóng &rarr;</a>
                            </div></div>
                    </div>
                    <div class="col-12 col-md-6 col-lg-4">
                        <div class="card card-feature h-100"><div class="card-body">
                                <div class="icon"><i class="bi bi-person-badge"></i></div>
                                <h3 class="h5 mt-2">Cầu thủ</h3>
                                <p class="text-muted">Đăng ký cầu thủ: mã sinh viên, số áo, vị trí thi đấu.</p>
                                <a href="${ctx}/player" class="stretched-link">Xem cầu thủ &rarr;</a>
                            </div></div>
                    </div>
                    <div class="col-12 col-md-6 col-lg-4">
                        <div class="card card-feature h-100"><div class="card-body">
                                <div class="icon"><i class="bi bi-calendar-event"></i></div>
                                <h3 class="h5 mt-2">Lịch thi đấu và kết quả</h3>
                                <p class="text-muted">Xếp lịch trận đấu, nhập tỷ số sau khi thi đấu.</p>
                                <a href="${ctx}/match" class="stretched-link">Xem lịch thi đấu &rarr;</a>
                            </div></div>
                    </div>
                    <div class="col-12 col-md-6 col-lg-4">
                        <div class="card card-feature h-100"><div class="card-body">
                                <div class="icon"><i class="bi bi-list-ol"></i></div>
                                <h3 class="h5 mt-2">Bảng xếp hạng</h3>
                                <p class="text-muted">Tự động tính điểm: thắng 3, hòa 1, thua 0; xếp theo điểm và hiệu số.</p>
                                <a href="${ctx}/standing" class="stretched-link">Xem bảng xếp hạng &rarr;</a>
                            </div></div>
                    </div>
                    <div class="col-12 col-md-6 col-lg-4">
                        <div class="card card-feature h-100"><div class="card-body">
                                <div class="icon"><i class="bi bi-shield-lock"></i></div>
                                <h3 class="h5 mt-2">Phân quyền</h3>
                                <p class="text-muted">Khách chỉ xem; Quản trị viên đăng nhập để thêm, sửa, xóa dữ liệu.</p>
                                <c:choose>
                                    <c:when test="${empty sessionScope.user}"><a href="${ctx}/login" class="stretched-link">Đăng nhập &rarr;</a></c:when>
                                    <c:otherwise><span class="text-success">Bạn đã đăng nhập</span></c:otherwise>
                                </c:choose>
                            </div></div>
                    </div>
                </div>
            </section>

            <%-- ===== Tác nhân và quyền hạn ===== --%>
            <section class="mb-4">
                <h2 class="h4 mb-3">Tác nhân và quyền hạn</h2>
                <div class="table-box">
                    <div class="table-responsive">
                        <table class="table table-hover align-middle mb-0">
                            <caption class="caption-top">Phân quyền được kiểm soát bởi AuthFilter</caption>
                            <thead>
                                <tr><th>Chức năng</th><th class="text-center">Khách</th><th class="text-center">Quản trị viên</th></tr>
                            </thead>
                            <tbody>
                                <tr><td>Xem giải đấu, đội bóng, cầu thủ, lịch thi đấu</td>
                                    <td class="text-center"><i class="bi bi-check-lg text-success"></i></td>
                                    <td class="text-center"><i class="bi bi-check-lg text-success"></i></td></tr>
                                <tr><td>Xem bảng xếp hạng</td>
                                    <td class="text-center"><i class="bi bi-check-lg text-success"></i></td>
                                    <td class="text-center"><i class="bi bi-check-lg text-success"></i></td></tr>
                                <tr><td>Thêm / sửa / xóa giải đấu, đội, cầu thủ</td>
                                    <td class="text-center"><i class="bi bi-x-lg text-danger"></i></td>
                                    <td class="text-center"><i class="bi bi-check-lg text-success"></i></td></tr>
                                <tr><td>Xếp lịch và nhập kết quả trận đấu</td>
                                    <td class="text-center"><i class="bi bi-x-lg text-danger"></i></td>
                                    <td class="text-center"><i class="bi bi-check-lg text-success"></i></td></tr>
                            </tbody>
                        </table>
                    </div>
                </div>
                <c:if test="${empty sessionScope.user}">
                    <p class="small text-muted mt-2">Tài khoản demo: <code>admin</code> / <code>123456</code></p>
                </c:if>
            </section>

        </main>

        <%-- ================= FOOTER ================= --%>
        <footer class="py-3 mt-auto">
            <div class="container d-flex flex-column flex-md-row justify-content-between small">
                <span>&copy; 2026 Quản lý giải bóng đá sinh viên</span>
                <span>Đồ án cuối môn PRJ301 - JSP / Servlet / SQL Server</span>
            </div>
        </footer>

        <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
    </body>
</html>