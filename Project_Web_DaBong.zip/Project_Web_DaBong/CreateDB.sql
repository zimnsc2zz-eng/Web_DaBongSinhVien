CREATE DATABASE StudentFootballDB;
GO

USE StudentFootballDB;
GO

CREATE TABLE Roles (
    RoleID INT IDENTITY(1,1) PRIMARY KEY,
    RoleName VARCHAR(50) NOT NULL UNIQUE
);

INSERT INTO Roles (RoleName)
VALUES
('Admin'),
('Organizer'),
('TeamManager');

CREATE TABLE Teams (
    TeamID INT IDENTITY(1,1) PRIMARY KEY,
    TeamName NVARCHAR(100) NOT NULL,
    Logo VARCHAR(255),
    Description NVARCHAR(500)
);

CREATE TABLE Tournaments (
    TournamentID INT IDENTITY(1,1) PRIMARY KEY,
    TournamentName NVARCHAR(150) NOT NULL,
    Description NVARCHAR(500),
    StartDate DATE,
    EndDate DATE,
    RegistrationDeadline DATE,
    Status VARCHAR(30) DEFAULT 'Upcoming',

    CHECK (EndDate IS NULL OR StartDate IS NULL
           OR EndDate >= StartDate),

    CHECK (Status IN (
        'Upcoming',
        'Ongoing',
        'Completed',
        'Cancelled'
    ))
);


----------

CREATE TABLE Venues (
    VenueID INT IDENTITY(1,1) PRIMARY KEY,
    VenueName NVARCHAR(100) NOT NULL,
    Address NVARCHAR(255),
    Description NVARCHAR(255)
);

CREATE TABLE Users (
    UserID INT IDENTITY(1,1) PRIMARY KEY,
    Username VARCHAR(50) NOT NULL UNIQUE,
    Password VARCHAR(255) NOT NULL,
    FullName NVARCHAR(100) NOT NULL,
    Email VARCHAR(100) UNIQUE,
    Phone VARCHAR(15),

    RoleID INT NOT NULL,
    TeamID INT NULL,

    Status BIT DEFAULT 1,

    FOREIGN KEY (RoleID)
    REFERENCES Roles(RoleID),

    FOREIGN KEY (TeamID)
    REFERENCES Teams(TeamID)
);


CREATE TABLE Players (
    PlayerID INT IDENTITY(1,1) PRIMARY KEY,
    TeamID INT NOT NULL,
    PlayerName NVARCHAR(100) NOT NULL,
    DateOfBirth DATE,
    JerseyNumber INT,
    Position NVARCHAR(30),
    Status BIT DEFAULT 1,

    FOREIGN KEY (TeamID)
    REFERENCES Teams(TeamID),

    CHECK (JerseyNumber IS NULL OR JerseyNumber BETWEEN 1 AND 99),

    UNIQUE (TeamID, JerseyNumber)
);

CREATE TABLE Groups (
    GroupID INT IDENTITY(1,1) PRIMARY KEY,
    TournamentID INT NOT NULL,
    GroupName VARCHAR(10) NOT NULL,

    FOREIGN KEY (TournamentID)
    REFERENCES Tournaments(TournamentID),

    UNIQUE (TournamentID, GroupName)
);

CREATE TABLE TournamentTeams (
    TournamentTeamID INT IDENTITY(1,1) PRIMARY KEY,
    TournamentID INT NOT NULL,
    TeamID INT NOT NULL,
    GroupID INT NULL,
    RegistrationDate DATE DEFAULT GETDATE(),
    Status VARCHAR(30) DEFAULT 'Waiting',

    FOREIGN KEY (TournamentID)
    REFERENCES Tournaments(TournamentID),

    FOREIGN KEY (TeamID)
    REFERENCES Teams(TeamID),

    FOREIGN KEY (GroupID)
    REFERENCES Groups(GroupID),

    UNIQUE (TournamentID, TeamID),

    CHECK (Status IN (
        'Waiting',
        'Approved',
        'Rejected'
    ))
);

CREATE TABLE Matches (
    MatchID INT IDENTITY(1,1) PRIMARY KEY,

    TournamentID INT NOT NULL,
    GroupID INT NULL,

    HomeTeamID INT NOT NULL,
    AwayTeamID INT NOT NULL,

    VenueID INT NULL,

    MatchDate DATETIME,
    HomeScore INT NULL,
    AwayScore INT NULL,

    MatchStage VARCHAR(30) NOT NULL,
    Status VARCHAR(30) DEFAULT 'Scheduled',

    FOREIGN KEY (TournamentID)
    REFERENCES Tournaments(TournamentID),

    FOREIGN KEY (GroupID)
    REFERENCES Groups(GroupID),

    FOREIGN KEY (HomeTeamID)
    REFERENCES TournamentTeams(TournamentTeamID),

    FOREIGN KEY (AwayTeamID)
    REFERENCES TournamentTeams(TournamentTeamID),

    FOREIGN KEY (VenueID)
    REFERENCES Venues(VenueID),

    CHECK (HomeTeamID <> AwayTeamID),

    CHECK (HomeScore IS NULL OR HomeScore >= 0),

    CHECK (AwayScore IS NULL OR AwayScore >= 0),

    CHECK (MatchStage IN (
        'GROUP',
        'QUARTERFINAL',
        'SEMIFINAL',
        'THIRD_PLACE',
        'FINAL'
    )),

    CHECK (Status IN (
        'Scheduled',
        'Ongoing',
        'Completed',
        'Postponed',
        'Cancelled'
    )),

    CHECK (
        (MatchStage = 'GROUP' AND GroupID IS NOT NULL)
        OR
        (MatchStage <> 'GROUP' AND GroupID IS NULL)
    )
);






