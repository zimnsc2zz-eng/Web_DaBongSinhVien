<%-- 
    Document   : main
    Created on : Oct 6, 2026, 3:46:39 PM
    Author     : vanph
--%>

<%@page contentType="text/html" pageEncoding="UTF-8"%>
<!DOCTYPE html>
<html>
    <head>
        <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
        <title>JSP Page</title>
    </head>
    <body>
        <a href="Accounts">Account Management</a>
    </body>
</html>
