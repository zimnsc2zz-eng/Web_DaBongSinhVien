<%-- 
    Document   : Accounts
    Created on : Oct 6, 2026, 4:15:57 PM
    Author     : vanph
--%>

<%@page contentType="text/html" pageEncoding="UTF-8"%>
<%@page import="java.util.List" %>
<%@page import="viewmodels.AccountDTO" %>
<%@taglib uri="http://java.sun.com/jsp/jstl/core" prefix="c" %>
<!DOCTYPE html>
<html>
    <head>
        <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
        <title>JSP Page</title>
    </head>
    <body>
        <h1>List of Accounts</h1>

        <div>
            <form action="Accounts" method="GET" >
                Account <input type="search" name="txtSearch" value="${txtSearch}"> 
                <input type="submit" value="Search" id="btnSubmit" >
            </form>
        </div>
        <div>
            <form action="Accounts" method="GET" >
                <div>
                    <label>Role:  </label>
                    <select id="selec" name="select">
                        <c:forEach var="role" items="${Roles}">
                            <option value="${role.getRoleId()}">${role.getRoleName()}</option>

                        </c:forEach>
                    </select>
                </div>
                <input type="submit" value="Filter" id="btnFilter">
            </form>
        </div>

        <c:if test="${Accounts.isEmpty()}">
            K co account
        </c:if >


        <button>
            <a style="text-decoration: none;color: blue;" href="CreateAccount">Create New Account</a>
        </button>
        <button>
            <a style="text-decoration: none;color: blue;" href="CreateRole">Create New Role</a>
        </button>
        <c:if test="${!Accounts.isEmpty()}">
            <table style="background-color: antiquewhite; border-radius: 10px ; border: 1px solid black; margin-top: 20px; padding : 10px">
                <tr>
                    <td>AccountID</td>
                    <td>Password</td>
                    <td>RoleName</td>
                </tr>
                <c:forEach var="Accounts" items="${Accounts}">

                    <tr>
                        <td>${Accounts.getAccountId()}</td>
                        <td>${Accounts.getPassword()}</td>
                        <td>${Accounts.getRoleName()}</td>
                        <td><a style="text-decoration: none; font-size: 100%" href="AccountDetail?id=${Accounts.getAccountId()}">Detail</a></td>
                        <td><a style="text-decoration: none;font-size: 100%" href="EditAccount?id=${Accounts.getAccountId()}">Edit</a></td>
                    </tr>
                </c:forEach>
            </table>

        </c:if>
    </body>
</html>




