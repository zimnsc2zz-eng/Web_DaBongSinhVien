<%-- 
    Document   : CreateAccount
    Created on : Oct 20, 2026, 4:12:26 PM
    Author     : vanph
--%>

<%@page contentType="text/html" pageEncoding="UTF-8"%>
<%@page import="java.util.List" %>
<%@page import="viewmodels.AccountDTO" %>
<%@taglib uri="http://java.sun.com/jsp/jstl/core" prefix="c" %>
<!DOCTYPE html>
<html>
    <head>
        <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
        <title>Create Account</title>
    </head>
    <body>
        <h1>
            Create Account
        </h1>

        <div>
            <form action="CreateAccount" method="POST" >
                <div>
                    <label>Account Id:</label>
                    <input type="text" name="txtAccountId"> 
                </div>
                <div>
                    <label>Password :</label>
                    <input type="password" name="txtPassword" "> 
                </div>
                <div>
                    <label>Role:  </label>
                    <select id="select" name="select">
                        <c:forEach var="role" items="${Roles}">
                            <option value="${role.getRoleId()}">${role.getRoleName()}</option>

                        </c:forEach>
                    </select>
                </div>
                <input type="submit" value="Create" id="btnFilter">
            </form>
        </div>
    </body>
</html>
