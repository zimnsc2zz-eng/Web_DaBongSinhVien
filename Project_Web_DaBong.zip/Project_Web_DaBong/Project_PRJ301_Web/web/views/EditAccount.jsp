<%-- 
    Document   : EditAccount
    Created on : Oct 20, 2026, 5:01:37 PM
    Author     : vanph
--%>

<%@page contentType="text/html" pageEncoding="UTF-8"%>
<%@page import="java.util.List" %>
<%@page import="viewmodels.AccountDTO" %>
<%@page import="models.Role" %>
<%@taglib uri="http://java.sun.com/jsp/jstl/core" prefix="c" %>
<!DOCTYPE html>
<html>
    <head>
        <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
        <title>Edit Account</title>
    </head>
    <body>
        <h1>Edit Account</h1>
        <div>
            <form action="EditAccount" method="POST" >
                <div>
                    <label>Account ID:</label>
                    <input type="text" name="txtAccount" value="${Account.getAccountId()}" readonly=""> 
                </div>
                <div>
                    <label>Old Password:</label>
                    <input type="text" value="${Account.getPassword()}" readonly=""> 
                </div>
                <div>
                    <label>New Password :</label>
                    <input type="password" name="txtPassword" "> 
                </div>
                <div>
                    <label>Role:  </label>
                    <select id="selec" name="select">
                        <c:forEach var="role" items="${Roles}">
                            <option value="${role.getRoleId()}"<c:if test="${role.getRoleId()==Account.getRoleId()}">selected</c:if> >${role.getRoleName()}</option>
                        </c:forEach>
                    </select>

                </div>
                <input type="submit" value="Save" id="btnEdit">
            </form>
        </div>
    </body>
</html>
