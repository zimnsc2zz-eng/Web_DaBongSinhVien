<%-- 
    Document   : CreateRole
    Created on : Oct 22, 2026, 1:33:50 PM
    Author     : vanph
--%>

<%@page contentType="text/html" pageEncoding="UTF-8"%>
<%@page import="java.util.List" %>
<%@taglib uri="http://java.sun.com/jsp/jstl/core" prefix="c" %>
<!DOCTYPE html>
<html>
    <head>
        <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
        <title>Create Role</title>
    </head>
    <body>
        <h1>Create New Role</h1>
    <c:if test="${!Roles.isEmpty()}">
        <table style="background-color: antiquewhite; border-radius: 10px ; border: 1px solid black; margin-top: 20px; padding : 10px">
            <tr>
                <td>RoleId</td>
                <td>RoleName</td>
            </tr>
            <c:forEach var="Role" items="${Roles}">

                <tr>
                    <td>${Role.getRoleId()}</td>
                    <td>${Role.getRoleName()}</td>
                </tr>
            </c:forEach>
        </table>

    </c:if>
</body>
</html>
