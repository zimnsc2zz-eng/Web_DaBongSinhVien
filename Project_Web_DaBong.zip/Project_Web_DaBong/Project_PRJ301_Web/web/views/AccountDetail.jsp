<%-- 
    Document   : AccountDetail
    Created on : Oct 13, 2026, 4:24:47 PM
    Author     : vanph
--%>

<%@page contentType="text/html" pageEncoding="UTF-8"%>
<%@page import="viewmodels.AccountDTO" %>
<!DOCTYPE html>
<html>
    <head>
        <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
        <title>Account Detail</title>
    </head>
    <body>
        <h1>Detail</h1>
        <div>Account Id: ${requestScope.AccountDetail.getAccountId()} </div>
        <div>Password: ${requestScope.AccountDetail.getPassword()}</div>
        <div>Role: ${requestScope.AccountDetail.getRoleName()}</div>
    </body>
</html>
