<%-- 
    Document   : index
    Created on : Oct 1, 2026, 2:14:07 PM
    Author     : vanph
--%>

<%@page contentType="text/html" pageEncoding="UTF-8"%>
<!DOCTYPE html>
<html>
    <head>
        <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
        <title>Login</title>
    </head>
    <body>
        <h1>Login</h1>
        <form action="Login" method="POST">
            <div>
                <label>
                    Username :
                </label>
                <input type="text" name="txtUsername" value="${requestScope.username}">
            </div>
            <div>
                <label>
                    Password :
                </label>
                <input type="password" name="txtPassword" value="${requestScope.password}">
            </div>
            <div>
                <input type="submit" value="Login" name="btn">
            </div>
            ${Error}
        </form>
    </body>
</html>
