<%-- 
    Document   : indextest
    Created on : Nov 3, 2026, 5:52:26 PM
    Author     : vanph
--%>


<%@ page contentType="text/html; charset=UTF-8" pageEncoding="UTF-8" %>

<!DOCTYPE html>
<html>
    <head>
        <title>Giải bóng đá sinh viên</title>
        <meta charset="UTF-8">
    </head>

    <body>

        <!-- HEADER -->
        <h1>GIẢI BÓNG ĐÁ SINH VIÊN</h1>
        <p>Student Football Tournament</p>

        <hr>

        <!-- MENU -->
        <nav>
            <a href="index.jsp">Trang chủ</a> |
            <a href="tournaments.jsp">Giải đấu</a> |
            <a href="teams.jsp">Đội bóng</a> |
            <a href="matches.jsp">Lịch thi đấu</a> |
            <a href="results.jsp">Kết quả</a> |
            <a href="standings.jsp">Bảng xếp hạng</a>|
            <%
                String username = (String) session.getAttribute("username");
                String role = (String) session.getAttribute("role");
            %>
            <% if (username == null) { %>

            <a href="login.jsp">Đăng nhập</a>

            <% } else { %>

            Xin chào, <b><%= username %></b>

            <% if ("Admin".equals(role)) { %>
            | <a href="admin/index.jsp">Quản trị hệ thống</a>
            <% } else if ("Organizer".equals(role)) { %>
            | <a href="organizer/index.jsp">Quản lý giải đấu</a>
            <% } else if ("TeamManager".equals(role)) { %>
            | <a href="manager/index.jsp">Quản lý đội bóng</a>
            <% } %>
            | <a href="LogoutServlet">Đăng xuất</a>
            <% } %>
        </nav>

        <hr>

        <!-- BANNER -->
        <h2>CHÀO MỪNG ĐẾN VỚI GIẢI BÓNG ĐÁ SINH VIÊN</h2>

        <p>
            Nơi kết nối đam mê, giao lưu và thể hiện tài năng
            bóng đá của sinh viên.
        </p>

        <a href="tournaments.jsp">Xem giải đấu</a>

        <hr>

        <!-- LỊCH THI ĐẤU -->
        <h2>LỊCH THI ĐẤU SẮP TỚI</h2>

        <table border="1" cellpadding="10">
            <tr>
                <th>Ngày</th>
                <th>Đội nhà</th>
                <th>Đội khách</th>
                <th>Giờ</th>
            </tr>

            <tr>
                <td>10/11/2026</td>
                <td>Đội A</td>
                <td>Đội B</td>
                <td>15:00</td>
            </tr>

            <tr>
                <td>11/11/2026</td>
                <td>Đội C</td>
                <td>Đội D</td>
                <td>17:00</td>
            </tr>
        </table>

        <hr>

        <!-- KẾT QUẢ -->
        <h2>KẾT QUẢ GẦN NHẤT</h2>

        <table border="1" cellpadding="10">
            <tr>
                <th>Đội nhà</th>
                <th>Tỷ số</th>
                <th>Đội khách</th>
            </tr>

            <tr>
                <td>Đội A</td>
                <td>2 - 1</td>
                <td>Đội B</td>
            </tr>

            <tr>
                <td>Đội C</td>
                <td>0 - 0</td>
                <td>Đội D</td>
            </tr>
        </table>

        <hr>

        <!-- BẢNG XẾP HẠNG -->
        <h2>BẢNG XẾP HẠNG</h2>

        <table border="1" cellpadding="10">
            <tr>
                <th>Hạng</th>
                <th>Đội bóng</th>
                <th>Số trận</th>
                <th>Thắng</th>
                <th>Hòa</th>
                <th>Thua</th>
                <th>Điểm</th>
            </tr>

            <tr>
                <td>1</td>
                <td>Đội A</td>
                <td>3</td>
                <td>3</td>
                <td>0</td>
                <td>0</td>
                <td>9</td>
            </tr>

            <tr>
                <td>2</td>
                <td>Đội B</td>
                <td>3</td>
                <td>2</td>
                <td>0</td>
                <td>1</td>
                <td>6</td>
            </tr>

            <tr>
                <td>3</td>
                <td>Đội C</td>
                <td>3</td>
                <td>1</td>
                <td>0</td>
                <td>2</td>
                <td>3</td>
            </tr>
        </table>

        <hr>

        <!-- FOOTER -->
        <h3>GIẢI BÓNG ĐÁ SINH VIÊN</h3>

        <p>Đơn vị tổ chức: Ban tổ chức giải đấu</p>
        <p>Email: studentfootball@gmail.com</p>
        <p>© 2026 Student Football Tournament</p>

    </body>
</html>

