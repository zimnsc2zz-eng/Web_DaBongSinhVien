/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package dal;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import models.Role;
import viewmodels.AccountDTO;

/**
 *
 * @author vanph
 */
public class RoleDAO extends DBContext {

    PreparedStatement statement;
    ResultSet result;

    public List<Role> getRoles() {
        String sql = """
                     Select * from Roles
                     """;
        List<Role> accs = new ArrayList<>();
        try {
            statement = connection.prepareCall(sql);
            //statement.setString(1, id);
            result = statement.executeQuery();

            while (result.next()) {
                int roleId = result.getInt("roleId");
                String roleName = result.getString("roleName");
                accs.add(new Role(roleId, roleName));
            }
        } catch (SQLException e) {

        }
        return accs;
    }
}
