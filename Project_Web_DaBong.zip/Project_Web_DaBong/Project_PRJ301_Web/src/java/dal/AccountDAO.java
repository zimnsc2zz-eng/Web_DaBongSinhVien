/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package dal;

/**
 *
 * @author vanph
 */
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import models.Account;
import viewmodels.AccountDTO;

public class AccountDAO extends DBContext {

    //CRUD voi account
    PreparedStatement statement;
    ResultSet result;

    //R - Read by ID
    public Account getAccountById(String id) {
        String sql = """
                     Select * from Users where Username = ?
                     """;
        Account acc = null;
        try {
            statement = connection.prepareCall(sql);
            statement.setString(1, id);
            result = statement.executeQuery();

            while (result.next()) {
                String accountId = result.getString("accountId");
                String password = result.getString("password");
                int roleId = result.getInt("roleId");
                acc = new Account(accountId, password, roleId);
            }
        } catch (Exception e) {
        }
        return acc;
    }

    public List<AccountDTO> getAccounts() {
        String sql = """
                     Select a.accountId , a.password , r.roleName
                     from Accounts a join Roles r on a.roleId = r.roleId
                     """;
        List<AccountDTO> accs = new ArrayList<>();
        try {
            statement = connection.prepareCall(sql);
            //statement.setString(1, id);
            result = statement.executeQuery();

            while (result.next()) {
                String accountId = result.getString("accountId");
                String password = result.getString("password");
                String roleName = result.getString("roleName");
                accs.add(new AccountDTO(accountId, password, roleName));
            }
        } catch (SQLException e) {

        }
        return accs;
    }

    public AccountDTO getAccountDetailById(String accId) {
        String sql = """
                     Select a.accountId , a.password , r.roleName
                     from Accounts a join Roles r on a.roleId = r.roleId
                     where a.accountId = ?
                     """;
        AccountDTO accs = null;
        try {
            statement = connection.prepareCall(sql);
            statement.setString(1, accId);
            result = statement.executeQuery();

            while (result.next()) {
                String accountId = result.getString("accountId");
                String password = result.getString("password");
                String roleName = result.getString("roleName");
                accs = new AccountDTO(accountId, password, roleName);
            }
        } catch (SQLException e) {

        }
        return accs;

    }

    public List<AccountDTO> getAccountsSearch(String txtS) {
        //txtS = "%"+txtS+"%";
        String sql = """
                      Select a.accountId , a.password , r.roleName
                                           from Accounts a join Roles r on a.roleId = r.roleId
                                           where a.accountId like ?
                     """;
        List<AccountDTO> accs = new ArrayList<>();
        try {
            statement = connection.prepareCall(sql);
            statement.setString(1, "%" + txtS + "%");
            result = statement.executeQuery();

            while (result.next()) {
                String accountId = result.getString("accountId");
                String password = result.getString("password");
                String roleName = result.getString("roleName");
                accs.add(new AccountDTO(accountId, password, roleName));
            }
        } catch (SQLException e) {

        }
        return accs;
    }

    public List<AccountDTO> getAccountsByFilter(String filter) {
        String sql = """
                      Select a.accountId , a.password , r.roleName
                                           from Accounts a join Roles r on a.roleId = r.roleId
                                           where r.roleId = ?
                     """;
        List<AccountDTO> accs = new ArrayList<>();
        try {
            statement = connection.prepareCall(sql);
            statement.setString(1, filter);
            result = statement.executeQuery();

            while (result.next()) {
                String accountId = result.getString("accountId");
                String password = result.getString("password");
                String roleName = result.getString("roleName");
                accs.add(new AccountDTO(accountId, password, roleName));
            }
        } catch (SQLException e) {

        }
        return accs;

    }

    public void createAccount(Account newAcc) {
        String sql = """
                     INSERT INTO Accounts
                      VALUES (?, ?,?)
                     """;
        try {
            statement = connection.prepareCall(sql);
            statement.setString(1,newAcc.getAccountId());
            statement.setString(2,newAcc.getPassword());
            statement.setInt(3,newAcc.getRoleId());
            statement.executeUpdate();

            System.out.println("Da Them thanh cong");
        } catch (SQLException e) {

        }
    }

    public void editAccount(Account newAcc) {
                String sql = """
                    UPDATE Accounts
                     SET password = ?, roleId = ?
                     WHERE accountId = ?
                     """;
        try {
            statement = connection.prepareCall(sql);
            statement.setString(1,newAcc.getPassword());
            statement.setInt(2,newAcc.getRoleId());
            statement.setString(3,newAcc.getAccountId());
            statement.executeUpdate();

        } catch (SQLException e) {

        }
    }

}
