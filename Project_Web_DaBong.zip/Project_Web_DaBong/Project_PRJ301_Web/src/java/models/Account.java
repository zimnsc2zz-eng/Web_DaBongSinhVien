/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package models;

/**
 *
 * @author vanph
 */
public class Account {
    private String accountId; //char(8)
    private String password; //nvarchar
    private int roleId; //int

    public Account(String accountId, String password, int roleId) {
        this.accountId = accountId;
        this.password = password;
        this.roleId = roleId;
    }

    public Account() {
    }

    
    public String getAccountId() {
        return accountId;
    }

    public void setAccountId(String accountId) {
        this.accountId = accountId;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public int getRoleId() {
        return roleId;
    }

    public void setRoleId(int roleId) {
        this.roleId = roleId;
    }

    
    
}
